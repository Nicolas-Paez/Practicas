from django.urls import path
from .views import *

urlpatterns = [
    path('', users_dashboard, name='users_dashboard'),
]