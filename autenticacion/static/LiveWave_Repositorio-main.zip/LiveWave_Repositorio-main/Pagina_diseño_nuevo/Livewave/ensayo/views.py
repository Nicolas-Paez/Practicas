from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render,redirect,get_object_or_404
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.http import HttpResponse
from ensayo.models import *
from datetime import datetime,timedelta
from django.db.models import Avg, Count, Q
#from registration.models import Profile
from django.urls import reverse_lazy
from core.views import *
from validacion import *
# Create your views here.
import xlwt
import pandas as pd
def num_pag():
    return 1


num_elemento = num_pag()#desde core se importa el numero de elementos por página

from extensiones.validacion import *
'Cambiar nombre list_ensayo_active'  
@login_required  
def list_ensayo_active(request,page=None,search=None):
    
    #profiles = Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request, profiles)
    if page == None:
        page = request.GET.get('page')
    else:
        page = page
    if request.GET.get('page') == None:
        page = page
    else:
        page = request.GET.get('page')
    #logica que permite recibir la cadena de búsqueda y propoga a través del paginador
    if search == None:
        search = request.GET.get('search')
    else:
        search = search
    if request.GET.get('search') == None:
        search = search
    else:
        search = request.GET.get('search') 
    if request.method == 'POST':
        search = request.POST.get('search') 
        page = None
    #fin logica que permite recibir la cadena de búsqueda y propoga a través del paginador
#Cambiar parametros de búsqueda
    ensayo_all = [] #lista vacia para agrega la salida de la lista ya sea con la cadena de búsqueda o no
    if search is None or search.strip() == "" or search == 'NoNe':# si la cadena de búsqueda viene vacia
        ensayo_all = Ensayo.objects.filter(estado_ensayo='Activa').exclude(pk =0)
        paginator = Paginator(ensayo_all, num_elemento)  
        'falta cambiar el nombre del template y el html '
        ensayo_list = paginator.get_page(page)
        template_name = 'ensayo/list_ensayo_active.html'
        return render(request,template_name,{'ensayo_list':ensayo_list,'paginator':paginator,'page':page})
    else:#si la cadena de búsqueda trae datos
        ensayo_all =  Ensayo.objects.filter(nombre_ensayo=search).filter(estado_ensayo='Activa').order_by('nombre_ensayo').exclude(pk =0)#Ascendente         
        paginator = Paginator(ensayo_all, num_elemento)  
        ensayo_list = paginator.get_page(page)
        template_name = 'ensayo/list_ensayo_active.html'
        return render(request,template_name,{'ensayo_list':ensayo_list,'paginator':paginator,'page':page,'search':search })
'Cambiar nombre list_ensayo_deactivate'  
@login_required    
def list_ensayo_deactivate(request,page=None,search=None):
    
    #profiles = Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request', profiles')
    if page == None:
        page = request.GET.get('page')
    else:
        page = page
    if request.GET.get('page') == None:
        page = page
    else:
        page = request.GET.get('page')
    #logica que permite recibir la cadena de búsqueda y propoga a través del paginador
    if search == None:
        search = request.GET.get('search')
    else:
        search = search
    if request.GET.get('search') == None:
        search = search
    else:
        search = request.GET.get('search') 
    if request.method == 'POST':
        search = request.POST.get('search') 
        page = None
    #fin logica que permite recibir la cadena de búsqueda y propoga a través del paginador
    ensayo_all = [] #lista vacia para agrega la salida de la lista ya sea con la cadena de búsqueda o no
    if search is None or search.strip() == "" or search == 'NoNe':# si la cadena de búsqueda viene vacia
        ensayo_all = Ensayo.objects.filter(estado_ensayo='Deactivate').order_by('fecha_ensayo').exclude(pk =0)
        paginator = Paginator(ensayo_all, num_elemento)  
        'falta cambiar el nombre del template y el html '
        ensayo_list = paginator.get_page(page)
        template_name = 'ensayo/list_ensayo_deactivate.html'
        return render(request,template_name,{'ensayo_list':ensayo_list,'paginator':paginator,'page':page})
    else:#si la cadena de búsqueda trae datos
        ensayo_all =  Ensayo.objects.filter(nombre_ensayo=search).order_by('nombre_ensayo').exclude(pk =0)#Ascendente         
        paginator = Paginator(ensayo_all, num_elemento)  
        ensayo_list = paginator.get_page(page)
        template_name = 'ensayo/list_ensayo_deactivate.html'
        return render(request,template_name,{'ensayo_list':ensayo_list,'paginator':paginator,'page':page,'search':search })
    


'Cambiar completo'
@login_required
def ensayo_main(request):
    #profiles = Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request, profiles)
    template_name = 'ensayo/ensayo_main.html'
    return render(request,template_name,{})
'Cambiar nombre'    
@login_required

def ensayo_edit(request,ensayo_id):
    #profiles = Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request, profiles)
    if request.method == 'POST':
        nombre_ensayo = request.POST.get('nombre')
        if validar_soloString(nombre_ensayo)==False:
            messages.error(request,'El nombre de el ensayo no debe estar vacio y no debe contener solo numeros')
        ensayo_count = Ensayo.objects.filter(pk=ensayo_id).count()
        ensayo_data = Ensayo.objects.get(pk=ensayo_id) 
        if ensayo_count == 1:

            Ensayo.objects.filter(pk = ensayo_id).update(nombre_ensayo = nombre_ensayo)
            messages.success(request,'Ensayo  '+ ensayo_data.nombre_ensayo +' editado con éxito')                             
            '''cambiar nombre y html'''
            return redirect('list_ensayo_active')
        else:
            messages.error(request,'Hubo un error al editar el ensayo: '+ensayo_data.nombre_ensayo )
            return redirect('list_ensayo_active')    
    ensayo_data = Ensayo.objects.get(pk=ensayo_id) 
    
    template_name = 'ensayo/ensayo_edit.html'
    return render(request,template_name,{'category_data':ensayo_data})
'Cambiar nombre' 

@login_required  
def ensayo_ver(request, ensayo_id):
    #profiles = Profile.objects.get(user_id=request.user.id)
    #check_profile_ensayo(request, profiles)
    template_name = 'ensayo/ensayo_ver.html' 
    Ensayo.objects.filter(pk=ensayo_id)
    ensayo_data = Ensayo.objects.get(pk=ensayo_id) 
    return render(request, template_name, {'template_name': template_name,  'ensayo_id': ensayo_id,'ensayo_data':ensayo_data})

'Cambiar nombre' 
@login_required
def ensayo_deactivate(request,ensayo_id):
    #profiles= Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request, profiles)
    new_state = 'Deactivate'
    ensayo_count = Ensayo.objects.filter(pk=ensayo_id).count()
    ensayo_data = Ensayo.objects.get(pk=ensayo_id) 
    ensayo = Ensayo.objects.filter(ensayo_id=ensayo_id)
    if ensayo_count == 1:
        Ensayo.objects.filter(pk = ensayo_id).update(estado_ensayo = new_state)
        messages.success(request,'Ensayo  '+ ensayo_data.nombre_ensayo +' desactivada con éxito')                             
        '''cambiar nombre y html'''
        return redirect('list_ensayo_active')
    else:
        messages.error(request,'Hubo un error al desactivar el ensayo: '+ensayo_data.nombre_ensayo )
        '''cambiar nombre y html'''
        return redirect('list_ensayo_active') 
'Cambiar nombre' 
@login_required
def ensayo_activate(request,ensayo_id):
    #profiles= Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request, profiles)
    new_state = 'Activate'
    ensayo_count = Ensayo.objects.filter(pk=ensayo_id).count()
    ensayo_data = Ensayo.objects.get(pk=ensayo_id) 
    ensayo = Ensayo.objects.filter(ensayo_id=ensayo_id)
    if ensayo_count == 1:
        Ensayo.objects.filter(pk = ensayo_id).update(estado_ensayo = new_state)
        messages.success(request,'Ensayo  '+ ensayo_data.nombre_ensayo +' desactivada con éxito')                             
        '''cambiar nombre y html'''
        return redirect('list_ensayo_deactivate')
    else:
        messages.error(request,'Hubo un error al desactivar el ensayo: '+ensayo_data.nombre_ensayo )
        '''cambiar nombre y html'''
        return redirect('list_ensayo_deactivate') 

'Cambiar nombre' 
@login_required
def ensayo_delete(request,ensayo_id):
    #profiles = Profile.objects.get(user_id = request.user.id)
    #check_profile_ensayo(request, profiles)

    ensayo_count = Ensayo.objects.filter(pk=ensayo_id).count()
    ensayo_data = Ensayo.objects.get(pk=ensayo_id)     
    if ensayo_count == 1:
        Ensayo.objects.filter(ensayo_id=ensayo_id).delete()
        Ensayo.objects.get(pk=ensayo_id).delete()
        messages.success(request,'Ensayo '+ensayo_data.nombre_ensayo +' eliminada con éxito')
        return redirect('list_ensayo_deactivate')        
    else:
        messages.error(request,'Hubo un error al eliminar el Ensayo '+ensayo_data.nombre_ensayo)
        return redirect('list_ensayo_deactivate')
'''
def ensayo_dashboard(request):
    #FECHAS Aanual
    #Deactivate <- estado
    now = datetime.now()
    year_now=now.year
    #fin datos tarjeta 1
    #datos tarjeta 2 ensayo mensual
    month_now=now.month
    fecha_inicio_2=f'01/{month_now}/{year_now}'
    fecha_final_2=f'30/{month_now}/{year_now}'
    d_fecha_inicio_2 = datetime.strptime(fecha_inicio_2,'%d/%m/%Y')
    d_fecha_final_2 = datetime.strptime(fecha_final_2,'%d/%m/%Y')



    #Costos mensuales 
    total_invent_act=Producto.objects.filter(updated__range=(d_fecha_inicio_2,d_fecha_final_2), producto_state = ('Activa'))
    total_invent_all=Producto.objects.filter(producto_state = ('Activa'))
    total_invent_act_count=Producto.objects.filter(producto_state = ('Activa')).count()
    total_invent_deac_count=Producto.objects.filter(producto_state = ('Deactivate')).count()

    total_inv_pr=0
    total_inv_pr_all=0
    for invent in total_invent_act:
        
        total_inv_pr=total_inv_pr + invent.precio_producto*invent.stock_producto  ##segun el precio del producto

    for inv in total_invent_all:
        
        total_inv_pr_all= total_inv_pr_all + inv.precio_producto*inv.stock_producto

    #datos Segun su state
    productos_count = Producto.objects.all().count()
    producto_alto_count = Producto.objects.filter(estado_producto = 'Alto',producto_state = ('Activa')).count()
    producto_medio_count = Producto.objects.filter(estado_producto = 'Medio',producto_state = ('Activa')).count()
    producto_bajo_count = Producto.objects.filter(estado_producto = 'Bajo',producto_state = ('Activa')).count()
    data_set_reorden = [producto_alto_count,producto_medio_count,producto_bajo_count]
    data_label_reorden = ['Alto','Medio','Bajo']
    data_color_reorden = ['#338AFF','#FA1A3C','#28B463']

    #Segun su estado (ACTIVO O BLOQUEADO)
    producto_activo_count = Producto.objects.filter(producto_state = 'Activa').count()
    producto_bloqueado_count = Producto.objects.filter(producto_state = 'Deactivate').count()

    sum_producto_estado = producto_activo_count + producto_bloqueado_count
    if sum_producto_estado == 0:
        sum_producto_estado = 1
    data_rate_activos = round(float((producto_bloqueado_count/sum_producto_estado)*100),1)

    data_set_estados = [producto_activo_count,producto_bloqueado_count]
    data_label_estado = ['Activo','Bloqueado']
    data_color_estado = ['#338AFF','#FA1A3C']
    
    #####reorden
    sum_producto_buen_reorden = producto_alto_count + producto_medio_count
    if sum_producto_buen_reorden == 0:
        sum_producto_buen_reorden = 1
    data_rate_reorden = round(float((sum_producto_buen_reorden/producto_activo_count)*100),1)
    data_set_reorden = [producto_alto_count,producto_medio_count,producto_bajo_count]
    data_label_reorden = ['Alto','Bajo','Medio']
    data_color_reorden = ['#338AFF','#FA1A3C','#28B463']

    categorias_productos = Category_group.objects.all().count()

    
    #fin datos grafico 2
    template_name = 'ensayo/ensayo_dashboard.html'
    return render(request,template_name,{'producto_activo_count':producto_activo_count,'total_invent_all':productos_count,
                                         'categorias_productos':categorias_productos,
                                         'total_invent_act_count':total_invent_act_count,'total_invent_deac_count':total_invent_deac_count,

                                         'data_rate_activos':data_rate_activos,'data_set_estados':data_set_estados,'data_label_estado':data_label_estado,'data_color_estado':data_color_estado,
                                         'total_inv_pr_all':total_inv_pr_all,'total_inv_pr':total_inv_pr,
                                         'producto_alto_count':producto_alto_count,'producto_medio_count':producto_alto_count,
                                         'producto_bajo_orden':producto_bajo_count,'data_label_reorden':data_label_reorden,
                                         'data_color_reorden':data_color_reorden,'data_set_reorden':data_set_reorden,'data_rate_reorden':data_rate_reorden })

'''



    






