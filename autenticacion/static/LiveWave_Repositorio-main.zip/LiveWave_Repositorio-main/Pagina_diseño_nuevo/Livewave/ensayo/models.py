
from django.db import models #importa los metodos necesarios para trabajar con modellos
# Create your models here.
from django import forms


#datos generales del ensayo
class Ensayo(models.Model):
    codigo_ensayo = models.CharField(max_length=100, null=True, blank=True)
    nombre_ensayo = models.CharField(max_length=100, null=True, blank=True)
    #usuario=models.OneToOneField(Usuario, on_delete=models.CASCADE)
    fecha_ensayo=models.DateTimeField(auto_now=False, verbose_name='Fecha Ensayo')
    estado_ensayo = models.CharField(max_length=100, null=True, blank=True, default='Activa')
    class Meta:
        verbose_name = 'Ensayo'
        verbose_name_plural = 'Ensayos'
        ordering = ['codigo_ensayo','nombre_ensayo','fecha_ensayo','estado_ensayo']


    def __str__(self):
        return self.nombre_ensayo
    #resultados del ensayo por cada unidad de tiempo
class Resultado_ensayo(models.Model):
    tiempo=models.IntegerField(null=True,blank=True)
    fuerza=models.DecimalField(null=True,blank=True,decimal_places=6,max_digits=200)
    time_of_fly=models.DecimalField(null=True,blank=True,decimal_places=6,max_digits=200)
    esd=models.DecimalField(null=True,blank=True,decimal_places=6,max_digits=200)
    strain=models.DecimalField(null=True,blank=True,decimal_places=6,max_digits=200)
    stress=models.IntegerField(null=True,blank=True)

    ensayo= models.ForeignKey(Ensayo, on_delete=models.CASCADE, null=False,blank=False)
    class Meta:
        verbose_name= 'Resultado_ensayo'
        verbose_name_plural = 'Resultado_ensayos'
        ordering= ['tiempo','fuerza','time_of_fly','esd','strain','stress']

    def __str__(self):
        return self.tiempo
    #parametros sobre el ensayo
class Ensayo_detalle(models.Model):
    #completar

    velocidad_ensayo=models.IntegerField(null=True,blank=True)

    ensayo= models.ForeignKey(Ensayo, on_delete=models.CASCADE, null=False,blank=False)
    class Meta:
        verbose_name= 'Ensayo_detalle'
        verbose_name_plural = 'Ensayo_detalles'
        ordering= ['velocidad_ensayo']

    def __str__(self):
        return self.ensayo