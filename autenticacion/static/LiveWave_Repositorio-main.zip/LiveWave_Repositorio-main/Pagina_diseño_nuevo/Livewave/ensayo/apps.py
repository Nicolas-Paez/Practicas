from django.apps import AppConfig


class EnsayoConfig(AppConfig):
    name = 'ensayo'
