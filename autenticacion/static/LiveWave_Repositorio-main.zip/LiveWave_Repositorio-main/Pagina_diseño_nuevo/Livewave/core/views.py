from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.views import LoginView
from django.contrib import messages
from .forms import CustomUserCreationForm, CustomAuthenticationForm
from django.contrib.auth.decorators import login_required
from core.views import *
from django.template.loader import get_template
# Create your views here.
from django.shortcuts import render, redirect
def home(request):
    return render(request, 'home.html') #Página base
@login_required
def modules(request):
    return render(request, 'modules.html')

def modules2(request):
    return render(request, 'modules2.html')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


class CustomLoginView(LoginView):
    form_class = CustomAuthenticationForm

    def form_invalid(self, form):
        messages.error(self.request, 'Nombre de usuario o contraseña incorrectos.')
        return super().form_invalid(form)

    def form_valid(self, form):
        messages.success(self.request, 'Inicio de sesión exitoso.')
        return super().form_valid(form)
def check_profile_inventario(request,profiles):
    if not(profiles.group_id == 1 or  profiles.group_id == 2) :
        messages.add_message(request, messages.INFO, 'Intenta ingresar a un área para la que no tiene permisos')
        return redirect('check_group_main')
    

def lista_usuario(request):
    return render(request, 'lista_usuario.html')

def check_profile_admin(request,profiles):
    if profiles.group_id != 1:
        messages.add_message(request, messages.INFO, 'Intenta ingresar a un área para la que no tiene permisos')
        return redirect('check_group_main')

def check_profile_inventario(request,profiles):
    if not(profiles.group_id == 1 or  profiles.group_id == 2) :
        messages.add_message(request, messages.INFO, 'Intenta ingresar a un área para la que no tiene permisos')
        return redirect('check_group_main')

def check_profile_proveedor(request,profiles):
    if not(profiles.group_id == 1 or  profiles.group_id == 3) :
        messages.add_message(request, messages.INFO, 'Intenta ingresar a un área para la que no tiene permisos')
        return redirect('check_group_main')
    
def check_profile_venta(request,profiles):
    if not(profiles.group_id == 1 or  profiles.group_id == 4) :
        messages.add_message(request, messages.INFO, 'Intenta ingresar a un área para la que no tiene permisos')
        return redirect('check_group_main')
