from django.urls import path
from .views import CustomLoginView
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('modules', modules, name='modules'),
    path('modules2', modules2, name='modules2'),
    path('register/', register , name='register'),
    path('lista_usuario/', lista_usuario, name='lista_usuario'),
    path('login/', CustomLoginView.as_view(), name='login'),
]
