from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.backends import ModelBackend
from .models import CustomUser

from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser
from registration2.models import Profile


class CustomUserCreationForm(UserCreationForm):
    phone = forms.CharField(max_length=15, required=False)
    address = forms.CharField(max_length=255, required=False)
    region = forms.CharField(max_length=50, required=False)
    comuna = forms.CharField(max_length=50, required=False)
    otro_dato = forms.CharField(max_length=100, required=False)

    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ('rut', 'first_name', 'last_name', 'email', 'phone', 'address', 'region', 'comuna', 'otro_dato')

        password1 = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
        )
        password2 = forms.CharField(
        label="Confirmar Contraseña",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )
class ProfileForm(forms.ModelForm):
    token_app_session = forms.CharField(max_length=255, required=False, label='Token de la sesión de la app')
    first_session = forms.DateTimeField(required=False, label='Primera sesión', widget=forms.TextInput(attrs={'type': 'datetime-local'}))
    group_id = forms.IntegerField(required=True, label='Grupo')

    class Meta:
        model = Profile
        fields = ['token_app_session', 'first_session', 'group_id']
class CustomAuthenticationForm(AuthenticationForm):
    error_messages = {
        'invalid_login': 'Nombre de usuario o contraseña incorrectos.',
        'inactive': 'Esta cuenta está inactiva.',
    }
    username = forms.CharField(label='RUT')

