from django.db import models
from django.contrib.auth.models import User, Group, Permission

# Modelos relacionados con Ensayo
class Material(models.Model):
    nombre = models.CharField(max_length=255)
    forma = models.CharField(max_length=255)

    def __str__(self):
        return self.nombre

class Ensayo(models.Model):
    nombre = models.CharField(max_length=255)
    fecha = models.DateTimeField(auto_now_add=True)
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    material = models.ForeignKey(Material, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

class EnsayoDetalle(models.Model):
    ensayo = models.ForeignKey(Ensayo, on_delete=models.CASCADE)
    velocidad_ensayo = models.FloatField()

class Conexion(models.Model):
    ensayo = models.ForeignKey(Ensayo, on_delete=models.CASCADE)
    generador_funciones = models.CharField(max_length=255)
    maquina_traccion = models.CharField(max_length=255)
    camara = models.CharField(max_length=255)

class ResultadoEnsayo(models.Model):
    ensayo = models.ForeignKey(Ensayo, on_delete=models.CASCADE)
    fuerza = models.FloatField()
    tiempo = models.FloatField()

class Analisis(models.Model):
    ensayo = models.ForeignKey(Ensayo, on_delete=models.CASCADE)
    nota = models.CharField(max_length=255)

class AnalisisResultado(models.Model):
    resultado_ensayo = models.ForeignKey(ResultadoEnsayo, on_delete=models.CASCADE)
    analisis = models.ForeignKey(Analisis, on_delete=models.CASCADE)

