from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404, redirect
from .models import Ensayo, Material
from django.contrib.auth.decorators import login_required

@login_required
def lista_ensayos(request):
    ensayos = Ensayo.objects.all()
    return render(request, 'ensayo/lista.html', {'ensayos': ensayos})

@login_required
def crear_ensayo(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        usuario = request.user
        material_id = request.POST['material_id']
        material = get_object_or_404(Material, pk=material_id)
        
        nuevo_ensayo = Ensayo(nombre=nombre, usuario=usuario, material=material)
        nuevo_ensayo.save()
        return redirect('lista_ensayos')
    
    materiales = Material.objects.all()
    return render(request, 'ensayo/crear.html', {'materiales': materiales})
