from django.apps import AppConfig


class HistorialConfig(AppConfig):
    name = 'historial'
