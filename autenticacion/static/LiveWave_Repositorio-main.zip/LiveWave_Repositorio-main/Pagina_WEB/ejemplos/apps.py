from django.apps import AppConfig


class EjemplosConfig(AppConfig):
    name = 'ejemplos'
