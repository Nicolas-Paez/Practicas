import ctypes
import time
import psycopg2
from psycopg2 import sql

# Cargar la biblioteca del SDK de CompuScope
cs = ctypes.CDLL("CompuScope.dll")

# Inicializar la tarjeta
cs.CsInitialize()

# Obtener el handle del sistema
handle = ctypes.c_int()
cs.CsGetSystem(ctypes.byref(handle), 0)

# Configurar los parámetros de adquisición
sample_rate = 1000000  # 1 MHz
num_channels = 4  # Ejemplo con 4 canales disponibles
record_length = 10000  # Número de muestras a capturar por canal

# Configurar la tarjeta con el número de canales
cs.CsSetSampleRate(handle, ctypes.c_double(sample_rate))
cs.CsSetChannelCount(handle, ctypes.c_int(num_channels))

# Conectar a la base de datos PostgreSQL
'''conn = psycopg2.connect(
    dbname="your_database_name",
    user="your_username",
    password="your_password",
    host="your_host",
    port="your_port"
)
cursor = conn.cursor()

# Crear una tabla para almacenar los datos si no existe
cursor.execute(
    CREATE TABLE IF NOT EXISTS data (
        timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        channel INTEGER,
        sample_index INTEGER,
        value INTEGER
    )
)
conn.commit()
'''
# Bucle infinito para capturar y guardar datos
try:
    while True:
        # Iniciar la adquisición
        cs.CsDo(handle, ctypes.c_int(1))  # Acción para comenzar (ACTION_START)

        # Esperar a que se complete la adquisición
        status = ctypes.c_int(0)
        while status.value != 1:
            cs.CsGetStatus(handle, ctypes.byref(status))
            time.sleep(0.01)  # Intervalo pequeño para revisar el estado

        # Crear buffers separados para cada canal
        buffers = []
        for channel in range(num_channels):
            buffers.append((ctypes.c_short * record_length)())  # Crear un buffer para cada canal

        # Transferir los datos de cada canal
        for channel in range(num_channels):
            cs.CsTransfer(handle, ctypes.byref(buffers[channel]), record_length)
        '''
        # Guardar los datos en la base de datos
        for channel in range(num_channels):
            for index, value in enumerate(buffers[channel]):
                cursor.execute(
                    INSERT INTO data (channel, sample_index, value)
                    VALUES (%s, %s, %s)
                , (channel + 1, index, value))
        
        # Confirmar los cambios
        conn.commit()
        '''
        # Opción para hacer una pequeña pausa antes de la siguiente captura
        time.sleep(0.5)  # Ajusta el tiempo si necesitas un intervalo entre capturas

except KeyboardInterrupt:
    # Cuando se interrumpe manualmente, cerramos el sistema
    print("Captura de datos interrumpida.")
    cs.CsClose(handle)
    '''conn.close()'''
