from gui import * 
import serial
import os
import sys 
import json
from dg1022 import dg1022
from tiepie_lib import tiepie_osc
from os import path
import matplotlib.pyplot as plt
from Phidget22.PhidgetException import *
from Phidget22.Phidget import *
from Phidget22.Devices.VoltageRatioInput import *
from scipy import signal
import numpy as np
import pandas as pd
import time
import json
from datetime import date
from PyQt5 import QtCore, QtGui, QtWidgets
class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, *args, **kwargs):
        _translate = QtCore.QCoreApplication.translate
        QtWidgets.QMainWindow.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.tabWidget.setCurrentIndex(0)
        # intrumets handlers
        self.gen_handler = None
        self.osc_handler = None
        self.trc_handler = None
        self.phid_reader = None
        self.cam_handler = None
        self.tra_handler = None
        # shared variables
        self.task_reader = None
        self.task_arduino = None
        self.f_value = 0.0
        self.d_value = 0.0
        self.t_value = 0.0
        self.ch0 = 0.0
        self.ch1 = 0.0
        self.ch0_std = 0.0
        self.ch1_std = 0.0
        self.data_ard = 0.0
        # control the main mesurement loop
        self._generator = None
        self._timerId = None
        #
        #self.lcdNumber.display(self.t_value)
        #self.lcdNumber_2.display(self.d_value)
        #self.lcdNumber_3.display(self.f_value)
        # data containers
        self.items_gf = []
        # renames
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("MainWindow", "Conexiones"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("MainWindow", "Experimento Tiempo de vuelo"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), _translate("MainWindow", "Experimento de atenuación/Beta"))
        # validators
        self.lineEdit.setValidator(QtGui.QIntValidator(1, 10, self.lineEdit))
        self.lineEdit_2.setValidator(QtGui.QDoubleValidator(0.0, 50.0,2, self.lineEdit_2))
        self.lineEdit_3.setValidator(QtGui.QDoubleValidator(0.0, 5.0,2, self.lineEdit_3))
        self.dial.setMinimum(1)
        self.dial.setMaximum(100)
        self.dial.setValue(40)
        self.dial.valueChanged.connect(self.sliderMoved)
        self.label_13.setText(str(1))
        # range 
        self.ranges_f = [0.2,0.4,0.8,2,4,8,20,40,80] 
        self.ranges = [str(item) for item in self.ranges_f ]
        
        self.comboBox_2.addItems(self.ranges)
        self.comboBox_2.setCurrentIndex(4)
        self.comboBox_3.addItems(self.ranges)
        self.comboBox_3.setCurrentIndex(1)
        self.comboBox_4.addItems(self.ranges)
        self.comboBox_4.setCurrentIndex(4)
        self.comboBox_5.addItems(self.ranges)
        ## set pruebas--> configuracion por defecto tof
        self.lineEdit.setText('5')
        self.lineEdit_2.setText('5')
        self.lineEdit_3.setText('5')
        self.lineEdit_4.setText('200e6')
        self.lineEdit_5.setText('2000')
        self.lineEdit_6.setText('0.1')

        self.lineEdit_10.setText('Muestra')
        self.lineEdit_11.setText('12')
        self.lineEdit_9.setText('Aluminio')
        #
        ## set pruebas--> configuracion por defecto beta
        self.lineEdit_20.setText('200e6') # frec muestreo
        self.lineEdit_16.setText('200000') # numero de muestras
        self.lineEdit_17.setText('0.0') # tiempo de espera entre experimentos
        self.lineEdit_13.setText('3.0') # frecuencia de acciotacion em mhz
        self.lineEdit_12.setText('1.0') # amplitud inicial
        self.lineEdit_18.setText('0.1') # paso de amplitud
        self.lineEdit_19.setText('3.0') # amplitud final
        # load settings
        # connections setup
        self.pushButton.clicked.connect(self.cargar_gf)
        self.pushButton_2.clicked.connect(self.conect_gf)
        self.pushButton_3.clicked.connect(self.conect_os)
        self.pushButton_12.clicked.connect(self.set_gf_pulse)
        self.pushButton_8.clicked.connect(self.cargar_serial)
        self.pushButton_21.clicked.connect(self.cargar_arduino)
        self.pushButton_9.clicked.connect(self.conect_tra)
        self.pushButton_17.clicked.connect(self.conect_phi)
        self.pushButton_22.clicked.connect(self.conect_ard)
        # conecctions tof
        self.pushButton_6.clicked.connect(self.start_b)
        self.pushButton_7.clicked.connect(self.stop_b)
        self.pushButton_5.clicked.connect(self.medir)
        self.pushButton_16.clicked.connect(self.os_config)
        self.pushButton_4.clicked.connect(self.get_dir)

        # connections beta
        self.pushButton_13.clicked.connect(self.get_sample)
        self.pushButton_14.clicked.connect(self.start_amp)
        self.pushButton_18.clicked.connect(self.get_dir2)
        #self.pushButton_15.clicked.connect(self.stop_sweep)
    def stop_b(self):  # Connect to Stop-button clicked()
        print("entre_stop")
        if self._timerId is not None:
            self.killTimer(self._timerId)
        self._generator = None
        self._timerId = None
    def start_b(self):  # Connect to Start-button clicked()
        self.stop_b()  # Stop any existing timer
        self._generator = self.looptof()  # Start the loop
        self._timerId = self.startTimer(0) 
    def start_amp(self):
        self.stop_b()  # Stop any existing timer
        self._generator = self.loopamp()  # Start the loop
        self._timerId = self.startTimer(0) 
    def timerEvent(self, event):
        # This is called every time the GUI is idle.
        if self._generator is None:
            return
        try:
            next(self._generator)  # Run the next iteration
        except StopIteration:
            self.stop_b()  # Iteration has finshed, kill the timer
    def get_dir(self):
        directory = str(QtWidgets.QFileDialog.getExistingDirectory(self, "Select Directory"))  
        self.lineEdit_7.setText(directory)

    def get_dir2(self):
        directory = str(QtWidgets.QFileDialog.getExistingDirectory(self, "Select Directory"))  
        self.lineEdit_14.setText(directory)
    def repository(self,exp_typ,path_folder, i = 0):
        print(i)
        if i == 0:
            proyect_folder = path_folder+"/"+date.today().strftime("%y_%m_%d_")+exp_typ
        else:
            proyect_folder = path_folder+"/"+date.today().strftime("%y_%m_%d_")+exp_typ + str(i)
        if os.path.isdir(proyect_folder) == False:
            os.mkdir(proyect_folder)
        else:
            i = i+1
            proyect_folder = self.repository(exp_typ,path_folder,i)
        #print(path+'/'+date.today().strftime("%d_%m_%y"))
        return proyect_folder#path+'/'+date.today().strftime("%d_%m_%y")
    def save_config(self,path,exp='tof'):
        if exp == 'tof':
            config = {'Frecuencia_de_muestreo':self.osc_handler.scp.sample_frequency,
            'Numero_de_muestras':self.osc_handler.scp.record_length,
            'Espesor_muestra[mm]':self.lineEdit_11.text(),
            'Nombre_muestra':self.lineEdit_10.text(),
            'Material_muestra':self.lineEdit_9.text()}
        else:
            config = {'Frecuencia_de_muestreo':self.osc_handler.scp.sample_frequency,
            'Numero_de_muestras':self.osc_handler.scp.record_length,
            'Nombre_muestra':self.lineEdit_15.text(),
            'Material_muestra':self.lineEdit_21.text()}
        with open(path+'/config_exp.json', 'w') as fp:
            json.dump(config, fp)

    def looptof(self):
        fig, axis = plt.subplots(2)
        plt.show()
        last_t = self.t_value
        start_running = False
        t0 = time.time()
        t0_trac = last_t
        t_list,d_list,f_list, tof_list, ch0_list,ch1_list = [],[],[],[],[],[]
        sig_list = []
        work_path = self.repository('tof',self.lineEdit_7.text())
        print(work_path)
        axis[0].set_ylabel('Esfuerzo [Pa]')
        axis[0].set_xlabel('Deformacion')
        self.save_config(work_path)
        table_sinc = pd.DataFrame(data={'tiempo[s]':t_list,'distancia[mm]':d_list,'fuerza[kN]':f_list,
                                        'tof[us]':tof_list,'v_inductivo[V]':ch0_list,'v_strain[V]':ch1_list,'v_inductivo_std[V]':ch0_list,'v_strain_std[V]':ch1_list})
        table_sinc.to_csv(work_path+'/data.csv',index=False)
        f=open(work_path+'/sig.txt','a')
        while True:
            if self.t_value - last_t>0:
                start_running = True
                self.osc_handler.read()
                fig.canvas.draw()
                fig.canvas.flush_events()
                corr = signal.correlate(self.osc_handler.data[-1][0], self.osc_handler.data[-1][1], method = 'fft')
                #axes.vlines(np.argmax(corr),ymin = min(self.osc_handler.data[-1][0]), ymax = max(self.osc_handler.data[-1][0]))
                sig_array = np.array([self.osc_handler.data[-1][0],self.osc_handler.data[-1][1]])
                self.osc_handler.data = []
                axis[0].plot(-4*5.*self.ch1/(2.09*15.0),1000*self.f_value/(12.51e-3*15e-3),'.r')
                axis[1].plot(1000*self.f_value/(12.51e-3*15e-3),np.argmax(corr),'.r')
                #print('entre',self.t_value-t0_trac,self.t_value)
                last_t = self.t_value
                table_sinc = pd.DataFrame(data={'tiempo[s]':[self.t_value],'distancia[mm]':[self.d_value],'fuerza[kN]':[self.f_value],
                                                'tof[us]':[np.argmax(corr)],'v_inductivo[V]':[5.*self.ch0],'v_strain[V]':[5.*self.ch1],
                                                'v_inductivo_std[V]':[5.*self.ch0_std],'v_strain_std[V]':[5.*self.ch0_std],'data_ard':[self.data_ard]})
                table_sinc.to_csv(work_path+'/data.csv',index=False,mode = 'a',header = False)
                np.savetxt(f,sig_array,delimiter = ',')
            else:
                if start_running == True and self.t_value == 0:
                    f.close()
                    self.showdialog()
                    plt.close(fig)
                    self.stop_b()
                    
            yield        
        # callbacks and operative functions
    def loopamp(self):
        amp_i,amp_f,amp_stp = float(self.lineEdit_12.text()),float(self.lineEdit_19.text()),float(self.lineEdit_18.text())
        amps = np.arange(amp_i,amp_f+amp_stp,amp_stp)
        work_path = self.repository('beta',self.lineEdit_14.text())
        self.save_config(work_path,'beta')
        f1=open(work_path+'/sig.txt','a')
        f2=open(work_path+'/fft.txt','a')
        n2 = int(2**np.ceil(np.log2(np.abs(self.osc_handler.scp.record_length))))
        fig, axes = plt.subplots(2)
        plt.show()
        sample_freq = self.osc_handler.scp.sample_frequency
        n = 5
        for i,amp in enumerate(amps):
            for j in range(n):
                signal = self.medir_continua(float(self.lineEdit_13.text()),amp)
                print(i,amp)
                t = np.linspace(0,1,signal.shape[1])/sample_freq
                n2 = int(2**np.ceil(np.log2(np.abs(signal.shape[1]))))
                fft_out = np.abs(np.fft.fft(signal[1,:],n2))
                freq = np.fft.fftfreq(n2,d = 1/sample_freq)
                #axes[0].plot(t[:500],signal[0,:500])
                axes[0].plot(t[:200],signal[1,:200])
                axes[1].plot(freq,fft_out,'.')
                axes[1].set_xlim(0,float(self.lineEdit_13.text())*1e6*5)
                axes[1].set_yscale('log')
                #print(signal[0,:].shape,np.pad(signal[0,:],pad_width=(0,n2-signal[0,:].shape[0])).shape)
                np.savetxt(f1,np.array([np.pad(signal[0,:],pad_width=(0,n2-signal[0,:].shape[0])),np.pad(signal[1,:],pad_width=(0,n2-signal[1,:].shape[0]))]),delimiter = ',')
                np.savetxt(f2,fft_out,delimiter = ',')
                print(signal.shape,fft_out.shape)
            if(i+1 == len(amps)):
                f1.close()
                f2.close()
                self.showdialog()
                plt.close(fig)
                self.stop_b()               
            yield 

    def showdialog(self):
        msg = QtWidgets.QMessageBox()
        msg.setIcon(QtWidgets.QMessageBox.Information)
        msg.setText("Experimento terminado")
        msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg.exec_()
    def sliderMoved(self):
        self.label_13.setText(str(self.dial.value()))
    def cargar_gf(self):
        # look for possible function generators connected by pyvisa 
        self.comboBox.clear()
        self.gen_handler = dg1022()
        self.items_gf = self.gen_handler.name_list
        self.comboBox.addItems(self.items_gf)
    def conect_gf(self):
        # try to connect to the function generator
        if self.gen_handler != None:
            if self.gen_handler.connected == False:
                self.gen_handler.conect(self.comboBox.currentIndex())
            time.sleep(0.5)
            print('Generador de funciones conectado')
    def set_gf_pulse(self):
        if self.gen_handler != None:
            if self.gen_handler.connected == True:
                print('pulse!!!')
                print(self.lineEdit.text(),self.lineEdit_2.text(),self.lineEdit_3.text())
                if (self.lineEdit.text().isnumeric() and self.lineEdit_2.text().isnumeric() and self.lineEdit_3.text().isnumeric()):
                    self.gen_handler.gauss(float(self.lineEdit_2.text())*1e6,float(self.lineEdit.text()),float(self.lineEdit_3.text()))
                    self.gen_handler.write("FUNC USER")
                    self.gen_handler.write("TRIGger:SOURce IMM")
                    self.gen_handler.write("BURS:MODE TRIG")
                    self.gen_handler.use_custom_signal()
                    self.gen_handler.write("BURS:STAT ON")
                    self.gen_handler.write("BURS:INT:PER 0.01")    
                    self.gen_handler.write("BURS:NCYC 1")   
                    self.gen_handler.write("APPLy:SINusoid:CH2 4800,1.0,0.0")
                    self.gen_handler.write("OUTP:CH2 ON")
                    
    def conect_os(self):
        if self.osc_handler == None:
            self.osc_handler = tiepie_osc()
            self.osc_handler.connect()
            if self.osc_handler.connected:
                self.label.setText("Conectado")  
                print('Osciloscopio conectado')
    def os_config(self):
        print('medir !!!!',self.osc_handler)
        if self.osc_handler != None:
            self.osc_handler.sample_frequency = float(self.lineEdit_4.text()) #frecuencia de muestreo
            self.osc_handler.record_length = int(self.lineEdit_5.text())  #numero de muestras
            self.osc_handler.pre_sample_ratio = float(self.lineEdit_6.text())
            self.osc_handler.config(channels = [(0,float(self.comboBox_2.currentText())),(1,float(self.comboBox_3.currentText()))], trg_channel = 0)

    def medir(self):
        print('medir !!!!',self.osc_handler)
        if self.osc_handler != None:
            print(self.osc_handler.sample_frequency/1e6,self.osc_handler.scp.sample_frequency/1e6)
            t0 = time.time()
            self.osc_handler.read()
            fig = plt.figure() 
            axes = fig.add_subplot(111)
            axes.plot(self.osc_handler.data[-1][0])
            axes.plot(self.osc_handler.data[-1][1])
            self.osc_handler.data = []
            #self.osc_handler.sample_frequency = 1e4 #frecuencia de muestreo
            #self.osc_handler.record_length = 1000  #numero de muestras
            #self.osc_handler.pre_sample_ratio = 0.0
            #self.osc_handler.config(channels = [(2,float(self.comboBox_4.currentText()))], trg_channel = 2)
            #print(self.osc_handler.sample_frequency/1e6,self.osc_handler.scp.sample_frequency/1e6)
            #self.osc_handler.read()
            #axes.plot(self.osc_handler.data[-1][0])
            #self.osc_handler.data = []
            plt.show()
    def get_sample(self):
        signal = self.medir_continua(float(self.lineEdit_13.text()),float(self.lineEdit_19.text()))
        sample_freq = self.osc_handler.scp.sample_frequency
        fig, axes = plt.subplots(2)
        plt.show()
        t = np.linspace(0,1,signal.shape[1])/sample_freq
        fft_out = np.abs(np.fft.fft(signal[1,:]))
        freq = np.fft.fftfreq(signal.shape[1],d = 1/sample_freq)
        axes[0].plot(t[:500],signal[0,:500])
        axes[0].plot(t[:500],signal[1,:500])
        axes[1].plot(freq,fft_out,'.')
        axes[1].set_xlim(0,float(self.lineEdit_13.text())*1e6*5)
        axes[1].set_yscale('log')
        plt.show()
    def medir_continua(self, freq, amp, adaptative = False):
        self.gen_handler.write("BURS:STAT OFF")
        self.gen_handler.write("APPL:SIN {},{},0.0".format(freq*1e6,2.0*amp))
        self.gen_handler.write("OUTP ON")
        self.osc_handler.sample_frequency = float(self.lineEdit_20.text()) #frecuencia de muestreo
        self.osc_handler.record_length = int(self.lineEdit_16.text())  #numero de muestras  
        if adaptative == False:
            print(self.get_range(amp))
            self.osc_handler.config(channels = [(0,self.get_range(amp)),(1,self.get_range(4))], trg_channel = 0) # 
            self.osc_handler.data = []
            self.osc_handler.read()
        else:
            amp_m = amp
            count = 0 
            while True:
                self.osc_handler.config(channels = [(0,self.get_range(amp)),(1,self.get_range(4))], trg_channel = 0)
                #self.osc_handler.config(channels = [(0,self.get_range(amp)),(1,self.get_range(amp_m))], trg_channel = 0)
                self.osc_handler.data = []
                self.osc_handler.read()
                amp_mes = max(self.osc_handler.data[-1][1])
                f = 1.2
                print('Rango = ',self.get_range(amp_m),'Amp = ',amp_mes*f,'ADAPTATIVE_RANGE = ',self.get_range(f*amp_mes))
                if amp_mes*f > self.get_range(amp_m) or self.get_range(amp_m) == self.get_range(amp_mes*f) :
                    break
                else:
                    amp_m = amp_mes*f
                if count > 10:
                    break
                count = count +1
        self.gen_handler.write("OUTP OFF")
        return np.array([self.osc_handler.data[-1][0],self.osc_handler.data[-1][1]])
    def get_range(self, val):
        absolute_difference_function = lambda list_value : (list_value - val)>0
        return max(self.ranges_f, key=absolute_difference_function)
    def conect_phi(self):
        if self.phid_reader == None:
            self.phid_reader = Phidgets_reader()
            self.phid_reader.update_sig_ph.connect(self.update_phi)
            self.phid_reader.start()

    def cargar_serial(self):
        import serial.tools.list_ports
        ports = serial.tools.list_ports.comports()
        ports = [port for port,_,_ in sorted(ports)]
        self.comboBox_6.addItems(ports)
    
    def cargar_arduino(self):
        import serial.tools.list_ports
        ports = serial.tools.list_ports.comports()
        ports = [port for port,_,_ in sorted(ports)]
        self.comboBox_8.addItems(ports)        

    def conect_tra(self):
        if self.task_reader == None:
            self.task_reader = Traction_reader(self.comboBox_6.currentText())
            self.task_reader.update_sig.connect(self.update_trac)
            self.task_reader.start()
    def conect_ard(self):
        if self.task_arduino == None:
            self.task_arduino = Arduino_reader(self.comboBox_8.currentText())
            self.task_arduino.update_sig.connect(self.update_ard)
            self.task_arduino.start()    
    def update_trac(self,data):
        self.f_value = data[0]
        self.d_value = data[2]
        self.t_value = data[3]
        self.lcdNumber.display(data[3])
        self.lcdNumber_2.display(data[2])
        self.lcdNumber_3.display(data[0])        
    def update_phi(self,data):
        self.ch0 = data[0]
        self.ch1 = data[1]
        self.ch0_std = data[2]
        self.ch1_std = data[3]
    def update_ard(self,data):
        self.data_ard = data
        self.lcdNumber_4.display(data)
        #print(self.ch0,self.ch1)
    def closeEvent(self, event):
        reply = QtWidgets.QMessageBox.question(self, 'Window Close', '¿Estás seguro que deseas cerrar?',
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if reply == QtWidgets.QMessageBox.Yes:
            if self.gen_handler != None:
                if self.gen_handler.connected == True:
                    self.gen_handler.inst.close()
            if self.osc_handler != None:
                self.osc_handler.close()
            if self.task_reader != None:
                self.task_reader.close_sig.emit(True)
            if self.phid_reader != None:
                self.phid_reader.close_sig_ph.emit(True)

            if self.task_arduino != None:
                self.task_arduino.close_sig.emit(True)
            event.accept()
            print('Window closed')
            # save the settings
        else:
            event.ignore()
class Traction_reader(QtCore.QThread):
    close_sig = QtCore.pyqtSignal(bool)
    update_sig = QtCore.pyqtSignal(list)
    def __init__(self, port):
        super(Traction_reader, self).__init__()
        # Store constructor arguments (re-used for processing)
        self.port = port
        self.close_sig.connect(self.handle_close)
        self.close = False
    def handle_close(self,val):
        self.close = val
    def run(self):
        serial_handler = serial.Serial(port = self.port, 
                                    baudrate = 9600, stopbits = serial.STOPBITS_ONE,
                                    parity  = serial.PARITY_NONE, bytesize = serial.EIGHTBITS,timeout = 2.0) 
        print(self.port)
        data_list = [] 
        data_line = ''
        while self.close == False:
            data = serial_handler.read().decode("utf-8") 
            if data == '{':
                data_line = data_line + data
                while data != '}':
                    data = serial_handler.read().decode("utf-8") 
                    data_line = data_line + data
            if len(data_line)>2:
                data_list = [float(item) for item in data_line[1:-1].split(',')]
                #print(data_list)
                self.update_sig.emit(data_list)
                data_line = ''
        print('cerre!!!')
        serial_handler.close()           
class Arduino_reader(QtCore.QThread):
    close_sig = QtCore.pyqtSignal(bool)
    update_sig = QtCore.pyqtSignal(str)
    def __init__(self, port):
        super(Arduino_reader, self).__init__()
        # Store constructor arguments (re-used for processing)
        self.port = port
        self.close_sig.connect(self.handle_close)
        self.close = False
    def handle_close(self,val):
        self.close = val
    def run(self):
        serial_handler = serial.Serial(port = self.port, 
                                    baudrate = 9600, timeout = 1.0) 
        print(self.port)
        while self.close == False:
            data = serial_handler.readline().decode("utf-8") 
            self.update_sig.emit(data[:-2])
        print('cerre!!!')
        serial_handler.close()       
class Phidgets_reader(QtCore.QThread):
    close_sig_ph = QtCore.pyqtSignal(bool)
    update_sig_ph = QtCore.pyqtSignal(list)

    def __init__(self):
        super(Phidgets_reader, self).__init__()
        # Store constructor arguments (re-used for processing)
        self.close_sig_ph.connect(self.handle_close)
        self.close = False
    def handle_close(self,val):
        self.close = val
    def run(self):
        ch0_hist = []
        ch1_hist = []       
        n_samples = 10
        data_list = [0,0] 
        ch0 = VoltageRatioInput()
        ch1 = VoltageRatioInput()
        ch0.setDeviceSerialNumber(578913)
        ch1.setDeviceSerialNumber(578913)
        ch1.setChannel(1)
        ch0.setChannel(0)
        ch0.openWaitForAttachment(5000)
        ch1.openWaitForAttachment(5000)
        ch0.setBridgeGain(0x1)
        ch1.setBridgeGain(0x8)
        ch0.setDataInterval(8)
        ch1.setDataInterval(8)
        ch0.setBridgeEnabled(True)
        ch1.setBridgeEnabled(True)
        time.sleep(0.1)
        print(str(ch0.getBridgeGain()))
        while self.close == False:
            try:
                data_list[0] = ch0.getVoltageRatio()
                data_list[1] = ch1.getVoltageRatio()
                ch0_hist.append(data_list[0])
                ch1_hist.append(data_list[1])
                if len(ch0_hist)>n_samples:
                    ch0_hist.pop(0)
                    ch1_hist.pop(0)
                self.update_sig_ph.emit([np.mean(np.array(ch0_hist)),np.mean(np.array(ch1_hist)),np.std(np.array(ch0_hist)),np.std(np.array(ch1_hist))])
                time.sleep(0.01)
            except AssertionError as error:
                print('problem phidgets  : '+ error)
        ch0.close()
        ch1.close()
if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
