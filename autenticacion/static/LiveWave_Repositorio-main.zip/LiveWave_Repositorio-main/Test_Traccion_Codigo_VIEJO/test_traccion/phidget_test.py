from Phidget22.PhidgetException import *
from Phidget22.Phidget import *
from Phidget22.Devices.VoltageRatioInput import *
import traceback
import time

ch0 = VoltageRatioInput()
ch1 = VoltageRatioInput()
ch0.setDeviceSerialNumber(578913)
ch1.setDeviceSerialNumber(578913)
ch1.setChannel(1)
ch0.setChannel(0)
ch0.openWaitForAttachment(5000)
ch1.openWaitForAttachment(5000)
ch0.setBridgeEnabled(True)
ch1.setBridgeEnabled(True)

print(ch0.getVoltageRatio())
print(ch1.getVoltageRatio())