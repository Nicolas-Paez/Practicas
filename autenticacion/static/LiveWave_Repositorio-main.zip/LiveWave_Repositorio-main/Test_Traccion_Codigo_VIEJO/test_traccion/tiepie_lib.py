from __future__ import print_function
import time
import os
import sys
import libtiepie

class tiepie_osc:
    def __init__(self):
        libtiepie.network.auto_detect_enabled = True
        libtiepie.device_list.update()
        self.scp = None
        self.sample_frequency = 1e3 # taza de muestreo por segundo
        self.record_length = 1e3  #numero de muestras
        self.pre_sample_ratio = 0.1 # porcentaje de pre muestras (entre 0-1)
        self.connected = False
        self.trigger_level = 0.5
        self.hystereses = 0.05
        self.data = []
    def connect(self):
        scp = None
        for item in libtiepie.device_list:
            if item.can_open(libtiepie.DEVICETYPE_OSCILLOSCOPE):
                scp = item.open_oscilloscope()
                if scp.measure_modes & libtiepie.MM_BLOCK:
                    self.connected = True
                    break
            else:
                scp = None
        if scp != None:
            scp.measure_mode = libtiepie.MM_BLOCK
            for ch in scp.channels:
                ch.trigger.enabled = False
                ch.enabled = False
        self.scp = scp
    
    def channels(self, channels = [(0,1.0)]):
        for ch,vrange in channels:
            self.scp.channels[ch].enabled = True
            self.scp.channels[ch].range = vrange
            self.scp.channels[ch].coupling = libtiepie.CK_DCV
        self.scp.trigger_time_out = 100e-3

    def trigger_setup(self, channel):
        self.scp.channels[channel].trigger.enabled = True
        self.scp.channels[channel].trigger.kind = libtiepie.TK_RISINGEDGE  
        self.scp.channels[channel].trigger.levels[0] = self.trigger_level  
        self.scp.channels[channel].trigger.hystereses[0] = self.hystereses
    def config(self, channels = [(0,1.0)], trg_channel = 0):
        self.scp.sample_frequency = self.sample_frequency
        self.scp.record_length  = int(self.record_length)
        self.scp.pre_sample_ratio = self.pre_sample_ratio
        self.channels(channels)
        self.trigger_setup(trg_channel)
        
    def read(self):
        self.scp.start()
        while not self.scp.is_data_ready:
            time.sleep(0.01)
        data = self.scp.get_data()
        self.data.append(data)
    def close(self):
        del self.scp
        self.scp = None

        
    


    