# -*- coding: utf-8 -*-
"""
Created on Wed Jan 20 11:35:46 2021

@author: alejandro
"""

from __future__ import print_function
import time
import os
import sys
import libtiepie
import matplotlib.pyplot as plt

# Print library info:


# Enable network search:
libtiepie.network.auto_detect_enabled = True

# Search for devices:
libtiepie.device_list.update()

scp = None
for item in libtiepie.device_list:
    if item.can_open(libtiepie.DEVICETYPE_OSCILLOSCOPE):
        scp = item.open_oscilloscope()
        if scp.measure_modes & libtiepie.MM_BLOCK:
            break
        else:
            scp = None
# Set measure mode:
scp.measure_mode = libtiepie.MM_BLOCK

# Set sample frequency:
scp.sample_frequency = 1e9  # 100 MHz

# Set record length:
scp.record_length = 1000  # 10000 samples

# Set pre sample ratio:
scp.pre_sample_ratio = 0  # 0 %

# For all channels:
for ch in scp.channels:
    # Enable channel to measure it:
    ch.enabled = True

    # Set range:
    ch.range = 2  # 8 V

    # Set coupling:
    ch.coupling = libtiepie.CK_DCV  # DC Volt

# Set trigger timeout:
scp.trigger_time_out = 100e-3  # 100 ms

# Disable all channel trigger sources:
for ch in scp.channels:
    ch.trigger.enabled = False

# Setup channel trigger:
ch = scp.channels[0]  # Ch 1

# Enable trigger source:
ch.trigger.enabled = True

# Kind:
ch.trigger.kind = libtiepie.TK_RISINGEDGE  # Rising edge

# Level:
ch.trigger.levels[0] = 0.5  # 50 %

# Hysteresis:
ch.trigger.hystereses[0] = 0.05  # 5 %

# Print oscilloscope info:

# Start measurement:
for i in range(5):
    scp.start()
    
    # Wait for measurement to complete:
    while not scp.is_data_ready:
        time.sleep(0.01)  # 10 ms delay, to save CPU time
    
    # Get data:
    data = scp.get_data()
    plt.plot(data[0],'.')
del scp
