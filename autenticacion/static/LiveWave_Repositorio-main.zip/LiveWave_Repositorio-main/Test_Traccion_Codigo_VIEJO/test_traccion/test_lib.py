# -*- coding: utf-8 -*-
"""
Created on Wed Jan 27 10:34:13 2021

@author: alejandro
"""

import dg1022
import matplotlib.pyplot as plt
import numpy as np
import time 
import os
import sys
import libtiepie

t = np.linspace(0,1,100)
y = np.exp(-((t-0.5)/0.5)**2)*np.sin(3*2*np.pi*t)

d = dg1022.dg1022()
d.conect(0) 
time.sleep(0.5)
#d.gauss(5000000,5)
#d.write("FUNC USER")
d.write("TRIGger:SOURce IMM")
# d.write("BURS:MODE TRIG")
d.write("VOLT:UNIT VPP")
d.write("VOLTage:HIGH 1")
d.write("VOLTage:LOW -1")

d.write("FREQ 2000000")
d.write("OUTP ON")
frequency = np.arange(2e6,7.5e6,1e5)
# for freq in frequency:
#     print(freq)
#     d.write('FREQ '+str(int(freq)))
#     time.sleep(1)

# d.use_custom_signal()
# d.write("BURS:STAT ON")
# d.write("BURS:INT:PER 0.01")


libtiepie.network.auto_detect_enabled = True
libtiepie.device_list.update()
scp = None
for item in libtiepie.device_list:
    if item.can_open(libtiepie.DEVICETYPE_OSCILLOSCOPE):
        scp = item.open_oscilloscope()
        if scp.measure_modes & libtiepie.MM_BLOCK:
            break
        else:
            scp = None
            

scp.measure_mode = libtiepie.MM_BLOCK
scp.sample_frequency = 5e9  # 100 MHz
scp.record_length = 10000  # 10000 samples
scp.pre_sample_ratio = 0.00  # 0 %
for n_ch,ch in enumerate(scp.channels):
    ch.enabled = True
    ch.range = 10.0
    ch.coupling = libtiepie.CK_DCV
scp.trigger_time_out = 100e-3  # 100 ms
# Disable all channel trigger sources:
for ch in scp.channels:
    ch.trigger.enabled = False

ch = scp.channels[0]  
ch.trigger.enabled = True
ch.trigger.kind = libtiepie.TK_RISINGEDGE  
ch.trigger.levels[0] = 0.2 
ch.trigger.hystereses[0] = 0.05
data_out = np.zeros((scp.record_length,3,len(frequency)))
for j,freq in enumerate(frequency):
    print(freq)
    d.write('FREQ '+str(int(freq)))
    #time.sleep(1)
    scp.start()
    while not scp.is_data_ready:
        time.sleep(0.01)
    data = scp.get_data()
    # plt.plot(data[0],'-r')
    # plt.plot(data[1],'-b')
    # plt.plot(data[2],'-g')
    for i in range(3):
        data_out[:,i,j] = np.array(data[i])
    time.sleep(0.5)
print(scp.sample_frequency)
del scp
d.write("OUTP OFF")

d.inst.close()
