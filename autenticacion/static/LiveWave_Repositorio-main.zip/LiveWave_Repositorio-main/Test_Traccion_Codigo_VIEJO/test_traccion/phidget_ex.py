from Phidget22.PhidgetException import *
from Phidget22.Phidget import *
from Phidget22.Devices.VoltageRatioInput import *
import traceback
import time

#Declare any event handlers here. These will be called every time the associated event occurs.

def onVoltageRatioChange(self, voltageRatio):
	print("VoltageRatio [" + str(self.getChannel()) + "]: " + str(voltageRatio))

def onAttach(self):
	print("Attach [" + str(self.getChannel()) + "]!")

def onDetach(self):
	print("Detach [" + str(self.getChannel()) + "]!")

def onError(self, code, description):
	print("Code [" + str(self.getChannel()) + "]: " + ErrorEventCode.getName(code))
	print("Description [" + str(self.getChannel()) + "]: " + str(description))
	print("----------")

def main():
	try:
		#Create your Phidget channels
		voltageRatioInput0 = VoltageRatioInput()
		voltageRatioInput1 = VoltageRatioInput()

		#Set addressing parameters to specify which channel to open (if any)
		voltageRatioInput0.setDeviceSerialNumber(578913)
		voltageRatioInput0.setChannel(0)
		voltageRatioInput1.setDeviceSerialNumber(578913)
		voltageRatioInput1.setChannel(1)

		#Assign any event handlers you need before calling open so that no events are missed.
		voltageRatioInput0.setOnVoltageRatioChangeHandler(onVoltageRatioChange)
		voltageRatioInput0.setOnAttachHandler(onAttach)
		voltageRatioInput0.setOnDetachHandler(onDetach)
		voltageRatioInput0.setOnErrorHandler(onError)
		voltageRatioInput1.setOnVoltageRatioChangeHandler(onVoltageRatioChange)
		voltageRatioInput1.setOnAttachHandler(onAttach)
		voltageRatioInput1.setOnDetachHandler(onDetach)
		voltageRatioInput1.setOnErrorHandler(onError)

		#Open your Phidgets and wait for attachment
		voltageRatioInput0.openWaitForAttachment(5000)
		voltageRatioInput1.openWaitForAttachment(5000)

		#Do stuff with your Phidgets here or in your event handlers.

		try:
			input("Press Enter to Stop\n")
		except (Exception, KeyboardInterrupt):
			pass

		#Close your Phidgets once the program is done.
		voltageRatioInput0.close()
		voltageRatioInput1.close()

	except PhidgetException as ex:
		#We will catch Phidget Exceptions here, and print the error informaiton.
		traceback.print_exc()
		print("")
		print("PhidgetException " + str(ex.code) + " (" + ex.description + "): " + ex.details)


main()