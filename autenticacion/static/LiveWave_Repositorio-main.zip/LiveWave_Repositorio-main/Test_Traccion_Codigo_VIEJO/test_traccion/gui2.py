# -*- coding: utf-8 -*-
"""
Created on Tue Feb  2 11:27:33 2021

@author: alejandro
"""

import sys 
import json

from PyQt5.QtCore import Qt

from PyQt5.QtWidgets import (QMainWindow, QApplication, QPushButton, QWidget, QAction, QTabWidget,
                             QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit, QComboBox,
                             QGroupBox)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import pyqtSlot
from dg1022 import dg1022
from tiepie_lib import tiepie_osc
from os import path

import time
# Creating the main window 
class App(QMainWindow):
    def __init__(self):
        super().__init__() 
        self.title = 'Sistema de medicion ultrasonico'
        self.left = 0
        self.top = 0
        self.width = 800    
        self.height = 600
        self.setWindowTitle(self.title) 
        self.setGeometry(self.left, self.top, self.width, self.height) 
        self.tab_widget = MyTabWidget(self) 
        self.setCentralWidget(self.tab_widget)
        self.show() 

# Creating tab widgets 
class MyTabWidget(QWidget): 
    def __init__(self, parent): 
        super(QWidget, self).__init__(parent) 
        self.layout = QVBoxLayout(self) 
  
        # Initialize tab screen 
        self.tabs = QTabWidget() 
        self.tab1 = QWidget() 
        self.tab2 = QWidget() 
        self.tab3 = QWidget() 
        #self.tabs.resize(300, 200) 
  
        # Add tabs 
        self.tabs.addTab(self.tab1, "Inicio") 
        self.tabs.addTab(self.tab2, "Tiempo de vuelo") 
        self.tabs.addTab(self.tab3, "Beta") 
  
        # Create first tab 
        self.tab1.layout = QVBoxLayout(self) 
        # box 1 generador de funciones
        self.gen_handler = None
        self.box1 = QGroupBox('Generador de funciones')
        self.box1.layout = QHBoxLayout(self)
        self.bt_load_ins = QPushButton('Cargar')
        self.bt_load_ins.clicked.connect(self.cargar_gf)
        self.box1.layout.addWidget(self.bt_load_ins)
        self.cb_gf = QComboBox()
        self.items_gf = ['Seleccionar Generador']
        self.cb_gf.addItems(self.items_gf)
        self.box1.layout.addWidget(self.cb_gf)
        self.bt_conn_ins = QPushButton('Conectar')
        self.bt_conn_ins.clicked.connect(self.conect_gf)
        self.box1.layout.addWidget(self.bt_conn_ins)
        self.box1.setLayout(self.box1.layout)
        self.tab1.layout.addWidget(self.box1) 

        # box 1 generador de funciones
        self.osc_handler = None
        self.box2 = QGroupBox('Osciloscopio')
        self.box2.layout = QHBoxLayout(self)
        self.bt_conn_osc = QPushButton('Conectar')
        self.bt_conn_osc.clicked.connect(self.conect_osc)
        self.label_conection = QLabel('No conectado')
        self.box2.layout.addWidget(self.bt_conn_osc)
        self.box2.layout.addWidget(self.label_conection)
        self.box2.setLayout(self.box2.layout)
        self.tab1.layout.addWidget(self.box2) 
        
        self.tab1.setLayout(self.tab1.layout)
        
        # tab 2 tiempo de vuelo 
        self.tab2.layout = QVBoxLayout(self) 
        self.box_conf_gen_tof =QGroupBox('Configuracion Generador de funciones')
        self.box_conf_gen_tof.layout = QGridLayout(self)
        self.box_conf_gen_tof.setLayout(self.box_conf_gen_tof.layout)
        
        names = ['N° Ciclos', 'Frecuencia','Unidades', 'Amplitud','Unidades']
        self.prefix = {'m':1e-3,' ':1e0,'k':1e3,'M':1e6,'G':1e9}
        self.tex_gen =[]
        for x,name in enumerate(names):
            label = QLabel(name)
            self.box_conf_gen_tof.layout.addWidget(label, 0,x)
            if name == 'Unidades':
                self.tex_gen.append(QComboBox())
                if(names[x-1] == 'Amplitud'):
                    self.tex_gen[-1].addItems([el+'V' for el in self.prefix.keys()][:2])
                if(names[x-1] == 'Frecuencia'):
                    self.tex_gen[-1].addItems([el+'Hz' for el in self.prefix.keys()][1:])
                self.box_conf_gen_tof.layout.addWidget(self.tex_gen[-1], 1,x)
            else:
                self.tex_gen.append(QLineEdit(name))
                self.box_conf_gen_tof.layout.addWidget(self.tex_gen[-1], 1,x)
        
        self.tab2.layout.addWidget(self.box_conf_gen_tof)

        self.box_conf_osc_tof =QGroupBox('Configuracion Osciloscopio')
        self.box_conf_osc_tof.layout = QGridLayout(self)        
        self.box_conf_osc_tof.setLayout(self.box_conf_osc_tof.layout)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Configuracion'), 0,0)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Frecuencia Muestreo'), 1,0)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Numero de muestras'), 2,0)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Fraccion Pre Muestreo'), 3,0)

        self.text_osc = []
        for i in range(3):
            self.text_osc.append(QLineEdit(''))
            self.box_conf_osc_tof.layout.addWidget(self.text_osc[-1], i+1,1)        

        self.box_conf_osc_tof.layout.addWidget(QLabel('Canal'), 0,2)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Señal Referencia'), 1,2)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Señal Recibida'), 2,2)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Sensor Inductivo'), 3,2)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Sensor de fuerza'), 4,2)
        self.box_conf_osc_tof.layout.addWidget(QLabel('Rango [V]'), 0,3)
        range_v = [0.2,0.4,0.8,2,4,8,20,40,80]

        for i in range(4):
            self.text_osc.append(QComboBox())
            self.text_osc[-1].addItems([str(el) for el in range_v])
            self.box_conf_osc_tof.layout.addWidget(self.text_osc[-1], i+1,3)     
        
        self.tab2.layout.addWidget(self.box_conf_osc_tof)

        self.box_conf_exp_tof =QGroupBox('Control experimento')
        self.box_conf_exp_tof.layout = QHBoxLayout(self)        
        self.box_conf_exp_tof.setLayout(self.box_conf_exp_tof.layout)

        self.box_one_tof = QGroupBox('Test TOF')
        
        self.box_one_tof.layout = QGridLayout(self)
        self.box_one_tof.setLayout(self.box_one_tof.layout)
        self.config_tof = QPushButton('Configurar')
        self.config_tof.clicked.connect(self.config_tof_callback)
        self.box_one_tof.layout.addWidget(self.config_tof,0,0,1, 2)
        self.start_tof = QPushButton('Medir') 
        self.start_tof.clicked.connect(self.on_click)
        self.box_one_tof.layout.addWidget(self.start_tof,1,0,1, 2)
        self.save_tof = QPushButton('Guardar') 
        self.save_tof.clicked.connect(self.on_click)
        self.box_one_tof.layout.addWidget(self.save_tof,2,1,1,1)
        self.file_tof = QPushButton('File') 
        self.file_tof.clicked.connect(self.on_click)
        self.box_one_tof.layout.addWidget(self.file_tof,2,0,1,1)

        self.box_conf_exp_tof.layout.addWidget(self.box_one_tof)

        self.box_start_tof = QGroupBox('Traccion TOF')

        self.box_conf_exp_tof.layout.addWidget(self.box_start_tof)

        self.tab2.layout.addWidget(self.box_conf_exp_tof)

        self.tab2.setLayout(self.tab2.layout)
        # Add tabs to widget 
        self.layout.addWidget(self.tabs) 
        self.setLayout(self.layout) 
    # callbacks tab1
    @pyqtSlot()
    def cargar_gf(self):
        self.cb_gf.clear()
        self.dg1022 = dg1022()
        self.items_gf = self.dg1022.name_list
        self.cb_gf.addItems(self.items_gf)
    @pyqtSlot()
    def conect_gf(self):
        if self.gen_handler == None:
            self.gen_handler = self.dg1022.conect(self.cb_gf.currentIndex())
            time.sleep(0.5)
    @pyqtSlot()
    def conect_osc(self):
        if self.osc_handler == None:
            self.osc_handler = tiepie_osc()
            self.osc_handler.connect()
            if self.osc_handler.connected:
                self.label_conection.setText("Conectado")
                print('entre')
    # callback tab2   

    def config_tof_callback(self):
        if self.tex_gen[0].text().isnumeric() and self.tex_gen[1].text().replace('.','',1).isnumeric():
            print(self.tex_gen[0].text(),int(float(self.tex_gen[1].text())*self.prefix[self.tex_gen[2].currentText()[0]]))
        else:
            print("ingresar numero de ciclos y frecuencia")
        #if (self.osc_handler != None) and (self.gen_handler != None):
            # cofigurar pulso y burst
            
#            self.gen_handler.gauss(5000000,5)
#            self.gen_handler.write("FUNC USER")
#            self.gen_handler.use_custom_signal()
#            self.gen_handler.write("BURS:STAT ON")
#            self.gen_handler.write("BURS:INT:PER 0.001")
    @pyqtSlot()
    def on_click(self):
        print('click')
    
        
if __name__ == '__main__':
    app = QApplication(sys.argv) 
    ex = App() 
    sys.exit(app.exec_()) 