import pyvisa
import time
rm = pyvisa.ResourceManager()
print(rm.list_resources())
dg = rm.open_resource(rm.list_resources()[0])

dg.write('FREQ MIN')
time.sleep(1)
dg.write('FREQ MAX')


